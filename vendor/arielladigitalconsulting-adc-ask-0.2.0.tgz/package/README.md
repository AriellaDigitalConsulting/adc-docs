# adc-ask

Framework-free web components for the ADC docs RAG service: `<adc-ask>` answers questions, and `<adc-search>`
searches the indexed docs. They have no runtime dependencies and their styles stay inside a shadow root, so they work
in any page or framework.

## Install

GitHub Packages needs a token to install, even for public packages. Add this `.npmrc` to your project:

```ini
@arielladigitalconsulting:registry=https://npm.pkg.github.com
//npm.pkg.github.com/:_authToken=${NODE_AUTH_TOKEN}
```

Then set `NODE_AUTH_TOKEN` to a token with `read:packages`, and run:

```bash
npm install @arielladigitalconsulting/adc-ask
```

In GitHub Actions, give the job `packages: read`, pass `NODE_AUTH_TOKEN: ${{ secrets.GITHUB_TOKEN }}`, and
allow the consuming repository under the package's **Manage Actions access** settings.

## Use

```html
<adc-ask collection="adc_docs"></adc-ask>
<script type="module">
  import '@arielladigitalconsulting/adc-ask';
</script>
```

In Astro, put both tags in a component. The `<script>` is bundled and runs only in the browser.

## Attributes

| Attribute | Default | Purpose |
|---|---|---|
| `endpoint` | production service | Service URL |
| `collection` | all collections | `adc_docs` or `lumapps_docs` |
| `mode` | floating | `inline` renders the panel in the page flow |
| `theme` | follows the system | `light` or `dark` |
| `heading` | `Ask ADC` | Panel title |
| `label` | same as `heading` | Launcher button text |
| `subtitle` | `Answers from the ADC documentation` | Text under the title |
| `placeholder` | `Ask a question` | Input placeholder |
| `welcome` | none | First message in the panel |
| `disclaimer` | `AI-generated answers can be wrong. Check the docs.` | Text under the input |

## Search

```html
<adc-search collection="adc_docs" link-from="https://docs.adc.dev" link-to=""></adc-search>
```

It searches as the user types, groups matching chunks by page and lists each page with a snippet. Press `/` or
`⌘K`/`Ctrl+K` to focus it, the arrow keys to move through results, and Enter to open one.

| Attribute | Default | Purpose |
|---|---|---|
| `endpoint` | production service | Search service URL |
| `collection` | all collections | `adc_docs` or `lumapps_docs`; with all collections, results show a source badge |
| `limit` | `10` | Chunks to fetch, at most 30 |
| `placeholder` | `Search the docs` | Input placeholder |
| `label` | same as `placeholder` | Accessible name of the input |
| `link-from` / `link-to` | none | Rewrites result URLs starting with `link-from` to start with `link-to` instead, so results open on the current site |
| `theme` | follows the system | `light` or `dark` |

Set the `titles` property to a `{path: title}` map to replace titles parsed from the indexed text. The element emits
`adc-search:results`, `adc-search:select` and `adc-search:error`. Use `--adc-search-width` to change its maximum width. On screens up to 640px wide the results span the screen,
starting `--adc-search-panel-top` (64px) from the top.

## Styling

Set these custom properties on the element: `--adc-ask-accent`, `--adc-ask-on-accent`, `--adc-ask-link`,
`--adc-ask-bg`, `--adc-ask-text`, `--adc-ask-muted`, `--adc-ask-line`, `--adc-ask-soft`, `--adc-ask-heading`,
`--adc-ask-font`, `--adc-ask-heading-font`, `--adc-ask-offset`, `--adc-ask-z` and `--adc-ask-height`.

## API

- `<adc-ask>` methods: `show()`, `close()`, `toggle()`, `submit(question)`
- `<adc-ask>` events: `adc-ask:answer` with `{question, answer, sources}`, and `adc-ask:error` with `{question, message, status}`

The optional `sources: [{title, url}]` response field is displayed when the service returns it.

## Release

Update `version` in `package.json`, then push a matching tag, such as `v0.1.1`. The publish workflow tests
the package and publishes it to GitHub Packages.
