# adc-ask

A framework-free web component that asks questions to the ADC docs RAG service. It has no runtime
dependencies and its styles stay inside a shadow root, so it works in any page or framework.

## Install

GitHub Packages needs a token to install, even for public packages. Add this `.npmrc` to your project:

```ini
@arielladigitalconsulting:registry=https://npm.pkg.github.com
//npm.pkg.github.com/:_authToken=${NODE_AUTH_TOKEN}
```

Then set `NODE_AUTH_TOKEN` to a token with `read:packages`, and run:

```bash
npm install @arielladigitalconsulting/adc-ask
```

In GitHub Actions, give the job `packages: read`, pass `NODE_AUTH_TOKEN: ${{ secrets.GITHUB_TOKEN }}`, and
allow the consuming repository under the package's **Manage Actions access** settings.

## Use

```html
<adc-ask collection="adc_docs"></adc-ask>
<script type="module">
  import '@arielladigitalconsulting/adc-ask';
</script>
```

In Astro, put both tags in a component. The `<script>` is bundled and runs only in the browser.

## Attributes

| Attribute | Default | Purpose |
|---|---|---|
| `endpoint` | production service | Service URL |
| `collection` | all collections | `adc_docs` or `lumapps_docs` |
| `mode` | floating | `inline` renders the panel in the page flow |
| `theme` | follows the system | `light` or `dark` |
| `heading` | `Ask ADC` | Panel title |
| `label` | same as `heading` | Launcher button text |
| `subtitle` | `Answers from the ADC documentation` | Text under the title |
| `placeholder` | `Ask a question` | Input placeholder |
| `welcome` | none | First message in the panel |
| `disclaimer` | `AI-generated answers can be wrong. Check the docs.` | Text under the input |

## Styling

Set these custom properties on the element: `--adc-ask-accent`, `--adc-ask-on-accent`, `--adc-ask-link`,
`--adc-ask-bg`, `--adc-ask-text`, `--adc-ask-muted`, `--adc-ask-line`, `--adc-ask-soft`, `--adc-ask-heading`,
`--adc-ask-font`, `--adc-ask-heading-font`, `--adc-ask-offset`, `--adc-ask-z` and `--adc-ask-height`.

## API

- Methods: `show()`, `close()`, `toggle()`, `submit(question)`
- Events: `adc-ask:answer` with `{question, answer, sources}`, and `adc-ask:error` with `{question, message, status}`

The optional `sources: [{title, url}]` response field is displayed when the service returns it.

## Release

Update `version` in `package.json`, then push a matching tag, such as `v0.1.1`. The publish workflow tests
the package and publishes it to GitHub Packages.
